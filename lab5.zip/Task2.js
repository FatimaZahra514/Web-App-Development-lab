const Product = {
    name: "Laptop",
    price: 50000,
    brand: "Lenovo ideaPad S340"
};
console.log(Product);
