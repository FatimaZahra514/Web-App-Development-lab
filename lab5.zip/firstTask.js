
console.log(typeof BigInt(1234567));
console.log(typeof Symbol("%"));




