for(let i =1;i<=5;i++)
    {console.log(i)}
let i =1;
while (i<=5)
{
    console.log("fats","kats");
    i++;
}
let word="Fatima";
for (let letter of word)
{
    console.log(letter);
}
let str="FATIMA";
let size =0;
for(let f of str)
{
    console.log("f=",f);
    size++;

}
console.log ("String size =" ,size);
do{
    let i=1;
    console.log(i);
    i++;
}
while(i<5);
let student = {
    name:"Fatima",
    age: 21,
    course : JS
};
