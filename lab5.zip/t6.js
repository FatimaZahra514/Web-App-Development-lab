let studentScore = prompt("Enter student score:");
if (studentScore >= 90) {
    console.log("Grade: A");
} else if (studentScore >= 80) {
    console.log("Grade: B");
} else if (studentScore >= 70) {
    console.log("Grade: C");
} else if (studentScore >= 60) {
    console.log("Grade: D");
} else {
    console.log("Grade: F");
}
