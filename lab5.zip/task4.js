let x = 5;
console.log(x++);
console.log(++x);
console.log(x--);
console.log(--x);