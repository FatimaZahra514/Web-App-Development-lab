const instagramProfile = {
    username: "fata.512",
    followers: 431,
    following: 277,
    posts: 0,
    bio: "Wonderlust and city dust. "
};
console.log(instagramProfile);