// 7. Print square of each number in an array using forEach
let numbers = [2, 3, 4, 5];
numbers.forEach(num => console.log(num * num));

