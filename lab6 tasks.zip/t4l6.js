// 4. Perform operations on Software Houses array
let softwareHouses = ["Google", "Microsoft", "Amazon", "Facebook"];
softwareHouses.shift(); 
softwareHouses.splice(1, 1, "Oracle"); 
softwareHouses.push("Tesla"); 
console.log(softwareHouses);

