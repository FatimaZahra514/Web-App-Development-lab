// 8. Filter out marks greater than 50
let studentMarks = [45, 55, 60, 30, 90, 20];
let filteredMarks = studentMarks.filter(mark => mark > 50);
console.log(filteredMarks);
