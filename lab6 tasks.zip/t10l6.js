// 10. Calculate product of all numbers using reduce
let numbersArray = [1, 2, 3, 4, 5];
let product = numbersArray.reduce((acc, num) => acc * num, 1);
console.log(product);