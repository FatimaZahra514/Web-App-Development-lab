function toggleMode() {
    const body = document.body;
    const button = document.querySelector('.toggle-btn');

    body.classList.toggle('dark-mode');
    body.classList.toggle('light-mode');

    // Change icon and text on button
    if (body.classList.contains('dark-mode')) {
      button.textContent = "🌙 Toggle Mode";
    } else {
      button.textContent = "🌞 Toggle Mode";
    }
  }

  function hoverEffect(btn) {
    btn.style.backgroundColor = "#666"; // Lighter on hover
  }

  function resetEffect(btn) {
    btn.style.backgroundColor = "#444"; // Back to default
  }